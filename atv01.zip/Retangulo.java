package atv01;

public class Retangulo implements Figura{
	private String nome;
	private double altura;
	private double base;
	
	public Retangulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}
	
	public String getNomeFigura() {
		this.nome = "Retangulo";
		return this.nome;
	}
	public double getArea() {
		double result = this.base * this.altura;
		return result;
	}
	
	public double getPerimetro() {
		double result = (this.base*2) + (this.altura*2);
		return result;
	}
}
