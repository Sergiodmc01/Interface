package atv01;

public class Hexagono implements Figura{
	private String nome;
	private double lado;
	
	public Hexagono(double lado) {
		super();
		this.lado = lado;
	}
	
	public String getNomeFigura() {
		this.nome = "Hexagono";
		return this.nome;
	}
	public double getArea() {
		double result = (this.lado * 6) * 2;
		result = result * Math.pow(3, 4);
		return result;
	}
	
	public double getPerimetro() {
		double result = (this.lado * 6);
		return result;
	}

}
