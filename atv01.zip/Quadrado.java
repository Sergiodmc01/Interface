package atv01;

public class Quadrado implements Figura{
	private String nome;
	private double lado;
	
	public Quadrado(double lado) {
		super();
		this.lado = lado;
	}
	
	public String getNomeFigura() {
		this.nome = "Quadrado";
		return this.nome;
	}
	public double getArea() {
		double result = this.lado * this.lado;
		return result;
	}
	
	public double getPerimetro() {
		double result = this.lado * 4;
		return result;
	}
}
