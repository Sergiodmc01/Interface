package atv01;

public class Principal {

	public static void main(String[] args) {
		
		Triangulo tri = new Triangulo(2);
		Quadrado qua = new Quadrado(2);
		Hexagono hex = new Hexagono(2);
		Retangulo ret = new Retangulo(2, 3);
		
		System.out.println(tri.getNomeFigura());
		System.out.println(tri.getArea());
		System.out.println(tri.getPerimetro());
		System.out.println("////////////");
		System.out.println(qua.getNomeFigura());
		System.out.println(qua.getArea());
		System.out.println(qua.getPerimetro());
		System.out.println("////////////");
		System.out.println(hex.getNomeFigura());
		System.out.println(hex.getArea());
		System.out.println(hex.getPerimetro());
		System.out.println("////////////");
		System.out.println(ret.getNomeFigura());
		System.out.println(ret.getArea());
		System.out.println(ret.getPerimetro());
	}

}
