package atv01;

public interface Figura {
	
	public String getNomeFigura();
	public double getArea();
	public double getPerimetro();
	
	


}
