package atv01;

public class Triangulo implements Figura {
	private	String nome;
	private double lado;
	
	public Triangulo(double lado) {
		super();
		this.lado = lado;
	}
	
	public String getNomeFigura() {
		this.nome = "Triângulo";
		return this.nome;
	}
	public double getArea() {
		double aux = this.lado * this.lado;
		double result = Math.pow(3, 4);
		result = result * aux;
		return result;
		
	}
	
	public double getPerimetro() {
		double result = this.lado * 3;
		return result;
	}
}
